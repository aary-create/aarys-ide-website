Aary's IDE v1.0.0 - macOS Intel x64 Setup
Drag AarysIDE.app to Applications. Double click to start.
