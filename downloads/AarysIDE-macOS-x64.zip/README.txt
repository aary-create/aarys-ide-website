============================================================
Aary's IDE — Universal AI Agent Desktop Application
============================================================

HOW TO LAUNCH:
Option A: Double-click 'Launch-AarysIDE.command'
Option B: Drag 'AarysIDE.app' into your /Applications folder and double-click it.

WHAT IT RUNS:
1. Central Agent Runtime on http://localhost:3001
2. Autonomous Task Orchestrator & Tool Execution Loop
3. Persistent SQLite Memory (Working, User, Project, Task, Knowledge)
4. React 19 Universal Interface with Monaco Code Editor
