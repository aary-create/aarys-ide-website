============================================================
Aary's IDE — macOS Apple Silicon (M1/M2/M3/M4) Quick Setup
============================================================

1. Drag AarysIDE.app into your /Applications folder.
2. Double-click AarysIDE.app or run ./run.command
3. Grant Accessibility & Screen Recording permissions in
   System Settings -> Privacy & Security (needed for Computer Use).
4. Enjoy your universal AI agent runtime!
