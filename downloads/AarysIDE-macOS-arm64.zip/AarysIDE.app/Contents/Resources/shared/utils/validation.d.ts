/**
 * Validate an email address format.
 */
export declare function isValidEmail(email: string): boolean;
/**
 * Validate a URL format.
 */
export declare function isValidUrl(url: string): boolean;
/**
 * Sanitize user input to prevent injection.
 */
export declare function sanitize(input: string): string;
/**
 * Validate API key format (non-empty, reasonable length).
 */
export declare function isValidApiKey(key: string): boolean;
/**
 * Check if a path is safe (no traversal attacks).
 */
export declare function isSafePath(path: string): boolean;
/**
 * Truncate a string to a max length with ellipsis.
 */
export declare function truncate(str: string, maxLen: number): string;
//# sourceMappingURL=validation.d.ts.map