/**
 * Encrypt a string value using AES-256-GCM.
 * Used for storing API keys and tokens securely.
 */
export declare function encrypt(text: string, key: string): string;
/**
 * Decrypt a string value encrypted with encrypt().
 */
export declare function decrypt(encryptedText: string, key: string): string;
/** Generate a cryptographically secure random ID */
export declare function generateId(length?: number): string;
/** Hash a string using SHA-256 */
export declare function hashString(input: string): string;
//# sourceMappingURL=crypto.d.ts.map