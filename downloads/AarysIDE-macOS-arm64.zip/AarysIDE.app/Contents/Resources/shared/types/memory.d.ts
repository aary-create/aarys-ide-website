export type MemoryId = string;
export type MemoryCategory = 'working' | 'user' | 'project' | 'task' | 'knowledge';
export interface MemoryEntry {
    id: MemoryId;
    userId: string;
    category: MemoryCategory;
    content: string;
    tags: string[];
    projectId?: string;
    taskId?: string;
    deviceId?: string;
    source: 'user' | 'agent' | 'system';
    importance: number;
    accessCount: number;
    createdAt: string;
    updatedAt: string;
    lastAccessedAt: string;
    expiresAt?: string;
}
export interface MemorySearchQuery {
    query: string;
    category?: MemoryCategory;
    projectId?: string;
    taskId?: string;
    tags?: string[];
    limit?: number;
    minImportance?: number;
}
export interface MemorySearchResult {
    entry: MemoryEntry;
    relevance: number;
}
export interface ConversationHistory {
    id: string;
    userId: string;
    title: string;
    messages: import('./agent.js').AgentMessage[];
    projectId?: string;
    deviceId?: string;
    summary?: string;
    createdAt: string;
    updatedAt: string;
}
export interface ProjectMemory {
    projectId: string;
    name: string;
    purpose?: string;
    requirements?: string[];
    architecture?: string;
    techStack?: string[];
    files?: string[];
    dependencies?: string[];
    decisions?: string[];
    currentState?: string;
    bugs?: string[];
    nextActions?: string[];
    repositoryUrl?: string;
    conversationRefs?: string[];
    createdAt: string;
    updatedAt: string;
}
//# sourceMappingURL=memory.d.ts.map