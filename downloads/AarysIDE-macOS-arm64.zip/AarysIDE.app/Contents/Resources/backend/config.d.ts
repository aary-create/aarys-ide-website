export declare const config: {
    readonly port: number;
    readonly host: string;
    readonly nodeEnv: string;
    readonly isDev: boolean;
    readonly jwtSecret: string;
    readonly encryptionKey: string;
    readonly allowedOrigins: string[];
    readonly databasePath: string;
    readonly memoryPath: string;
    readonly workspacePath: string;
    readonly ai: {
        readonly omniroute: {
            readonly apiKey: string;
            readonly baseUrl: string;
        };
        readonly openrouter: {
            readonly apiKey: string;
            readonly baseUrl: string;
        };
        readonly openai: {
            readonly apiKey: string;
            readonly baseUrl: "https://api.openai.com/v1";
        };
        readonly anthropic: {
            readonly apiKey: string;
            readonly baseUrl: "https://api.anthropic.com";
        };
        readonly gemini: {
            readonly apiKey: string;
            readonly baseUrl: "https://generativelanguage.googleapis.com";
        };
        readonly ollama: {
            readonly baseUrl: string;
        };
        readonly custom: {
            readonly apiKey: string;
            readonly baseUrl: string;
        };
    };
    readonly google: {
        readonly clientId: string;
        readonly clientSecret: string;
        readonly redirectUri: string;
    };
    readonly github: {
        readonly clientId: string;
        readonly clientSecret: string;
        readonly redirectUri: string;
    };
    readonly whatsapp: {
        readonly phoneNumberId: string;
        readonly businessAccountId: string;
        readonly accessToken: string;
        readonly verifyToken: string;
        readonly webhookUrl: string;
    };
};
export type Config = typeof config;
//# sourceMappingURL=config.d.ts.map