/**
 * Encrypt a credential (API key, token, etc.) for storage.
 */
export declare function encryptCredential(plainText: string): string;
/**
 * Decrypt a stored credential.
 */
export declare function decryptCredential(cipherText: string): string;
/**
 * Encrypt a JSON object for storage (e.g., config objects).
 */
export declare function encryptJson(obj: Record<string, unknown>): string;
/**
 * Decrypt a stored JSON object.
 */
export declare function decryptJson<T = Record<string, unknown>>(cipherText: string): T;
/**
 * Mask an API key for display (show first/last 4 chars).
 */
export declare function maskApiKey(apiKey: string): string;
//# sourceMappingURL=credentials.d.ts.map