/**
 * Generate the GitHub OAuth consent URL.
 */
export declare function getGitHubAuthUrl(state?: string): string;
/**
 * Exchange an authorization code for an access token.
 */
export declare function exchangeGitHubCode(code: string): Promise<{
    accessToken: string;
    tokenType: string;
    scope: string;
}>;
/**
 * Get the user's GitHub profile.
 */
export declare function getGitHubUserInfo(accessToken: string): Promise<{
    id: number;
    login: string;
    name: string;
    email: string | null;
    avatarUrl: string;
}>;
/**
 * Full GitHub OAuth callback handler.
 */
export declare function handleGitHubCallback(code: string, deviceId?: string): Promise<{
    token: string;
    refreshToken: string;
    sessionId: string;
    expiresAt: string;
    user: {
        id: string;
        email: string;
        name: string;
        avatarUrl?: string;
    };
}>;
//# sourceMappingURL=github.d.ts.map