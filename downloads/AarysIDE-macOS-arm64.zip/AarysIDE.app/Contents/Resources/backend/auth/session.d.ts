import type { Request, Response, NextFunction } from 'express';
export interface JWTPayload {
    userId: string;
    email: string;
    sessionId: string;
    deviceId?: string;
}
/**
 * Create a new JWT token pair (access + refresh).
 */
export declare function createTokens(payload: Omit<JWTPayload, 'sessionId'>): {
    token: string;
    refreshToken: string;
    sessionId: string;
    expiresAt: string;
};
/**
 * Verify a JWT token and return the payload.
 */
export declare function verifyToken(token: string): JWTPayload | null;
/**
 * Refresh an access token using a refresh token.
 */
export declare function refreshAccessToken(refreshToken: string): {
    token: string;
    expiresAt: string;
} | null;
/**
 * Invalidate a session (logout).
 */
export declare function invalidateSession(sessionId: string): void;
/**
 * Invalidate all sessions for a user.
 */
export declare function invalidateAllSessions(userId: string): void;
/**
 * Express middleware: Authenticate request via Bearer token.
 * Attaches `req.user` with userId/email/sessionId.
 */
export declare function authMiddleware(req: Request, res: Response, next: NextFunction): void;
/**
 * Optional auth middleware: Extracts user if token present, but doesn't block.
 */
export declare function optionalAuth(req: Request, _res: Response, next: NextFunction): void;
export declare function cleanupExpiredSessions(): void;
//# sourceMappingURL=session.d.ts.map