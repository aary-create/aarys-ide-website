/**
 * Generate the Google OAuth consent URL.
 */
export declare function getGoogleAuthUrl(state?: string): string;
/**
 * Exchange an authorization code for tokens.
 */
export declare function exchangeGoogleCode(code: string): Promise<{
    accessToken: string;
    refreshToken?: string;
    idToken?: string;
    expiresIn: number;
}>;
/**
 * Get the user's Google profile using an access token.
 */
export declare function getGoogleUserInfo(accessToken: string): Promise<{
    id: string;
    email: string;
    name: string;
    picture?: string;
}>;
/**
 * Full Google OAuth callback handler:
 * Exchange code → get user info → create or find user → create session.
 */
export declare function handleGoogleCallback(code: string, deviceId?: string): Promise<{
    token: string;
    refreshToken: string;
    sessionId: string;
    expiresAt: string;
    user: {
        id: string;
        email: string;
        name: string;
        avatarUrl?: string;
    };
}>;
//# sourceMappingURL=google.d.ts.map