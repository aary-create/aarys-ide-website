export {};
//# sourceMappingURL=file-gen.d.ts.map