// ============================================================
// Aary's IDE — Tool Registry
// Manages all available agent tools
// ============================================================
const tools = new Map();
export function registerTool(definition, handler) {
    tools.set(definition.name, { definition, handler });
}
export function getTool(name) {
    return tools.get(name);
}
export function listTools() {
    return Array.from(tools.values()).map(t => t.definition);
}
export function getToolsForAI() {
    return listTools().map(t => ({
        type: 'function',
        function: {
            name: t.name,
            description: t.description,
            parameters: {
                type: 'object',
                properties: t.parameters,
                required: Object.entries(t.parameters).filter(([_, p]) => p.required).map(([k]) => k),
            },
        },
    }));
}
export async function executeTool(request) {
    const tool = tools.get(request.toolName);
    if (!tool) {
        return { toolName: request.toolName, success: false, error: `Unknown tool: ${request.toolName}`, duration: 0 };
    }
    const start = Date.now();
    try {
        const result = await tool.handler(request.args, { sessionId: request.sessionId, workspacePath: undefined });
        return { toolName: request.toolName, success: true, result, duration: Date.now() - start };
    }
    catch (e) {
        return { toolName: request.toolName, success: false, error: e.message, duration: Date.now() - start };
    }
}
//# sourceMappingURL=registry.js.map