import type { ToolDefinition, ToolExecutionRequest, ToolExecutionResult } from '@aarys-ide/shared';
type ToolHandler = (args: Record<string, unknown>, context: {
    sessionId: string;
    workspacePath?: string;
}) => Promise<unknown>;
export declare function registerTool(definition: ToolDefinition, handler: ToolHandler): void;
export declare function getTool(name: string): {
    definition: ToolDefinition;
    handler: ToolHandler;
} | undefined;
export declare function listTools(): ToolDefinition[];
export declare function getToolsForAI(): {
    type: "function";
    function: {
        name: string;
        description: string;
        parameters: {
            type: string;
            properties: Record<string, import("@aarys-ide/shared").ToolParameter>;
            required: string[];
        };
    };
}[];
export declare function executeTool(request: ToolExecutionRequest): Promise<ToolExecutionResult>;
export {};
//# sourceMappingURL=registry.d.ts.map