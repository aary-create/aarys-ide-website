// ============================================================
// Aary's IDE — Task Queue & Background Runner
// ============================================================
import { updateTaskStatus } from '../agent/orchestrator.js';
class TaskQueue {
    queue = [];
    isProcessing = false;
    enqueue(task, execute) {
        this.queue.push({ task, execute });
        this.processNext();
    }
    async processNext() {
        if (this.isProcessing || this.queue.length === 0)
            return;
        this.isProcessing = true;
        const current = this.queue.shift();
        if (current) {
            updateTaskStatus(current.task.id, 'started');
            try {
                await current.execute();
                updateTaskStatus(current.task.id, 'completed', 100);
            }
            catch (err) {
                updateTaskStatus(current.task.id, 'failed');
            }
        }
        this.isProcessing = false;
        this.processNext();
    }
}
export const globalTaskQueue = new TaskQueue();
//# sourceMappingURL=queue.js.map