import type { Task } from '@aarys-ide/shared';
declare class TaskQueue {
    private queue;
    private isProcessing;
    enqueue(task: Task, execute: () => Promise<void>): void;
    private processNext;
}
export declare const globalTaskQueue: TaskQueue;
export {};
//# sourceMappingURL=queue.d.ts.map