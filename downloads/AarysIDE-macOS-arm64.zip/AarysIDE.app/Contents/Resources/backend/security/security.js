// ============================================================
// Aary's IDE — Security, Permissions & Audit Logging
// ============================================================
import { generateId } from '@aarys-ide/shared';
import { db } from '../database.js';
const pendingApprovals = new Map();
export function createApprovalRequest(taskId, action, description, risk, details) {
    const req = {
        id: generateId(),
        taskId,
        action,
        description,
        risk,
        details,
        status: 'pending',
        createdAt: new Date().toISOString(),
    };
    pendingApprovals.set(req.id, req);
    return req;
}
export function resolveApproval(id, approved) {
    const req = pendingApprovals.get(id);
    if (!req)
        return false;
    req.status = approved ? 'approved' : 'rejected';
    logAudit('system', approved ? 'approval_granted' : 'approval_rejected', req, req.risk);
    return true;
}
export function logAudit(userId, action, details, risk = 'low') {
    const id = generateId();
    db.prepare(`
    INSERT INTO audit_log (id, user_id, action, details, risk, timestamp)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(id, userId, action, JSON.stringify(details), risk, new Date().toISOString());
}
//# sourceMappingURL=security.js.map