import type { ApprovalRequest } from '@aarys-ide/shared';
export declare function createApprovalRequest(taskId: string, action: string, description: string, risk: 'low' | 'medium' | 'high' | 'critical', details: Record<string, unknown>): ApprovalRequest;
export declare function resolveApproval(id: string, approved: boolean): boolean;
export declare function logAudit(userId: string, action: string, details: Record<string, unknown>, risk?: string): void;
//# sourceMappingURL=security.d.ts.map