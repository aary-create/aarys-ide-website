export declare function synthesizeSpeech(text: string, voice?: string): Promise<Buffer>;
//# sourceMappingURL=tts.d.ts.map