export declare function transcribeAudio(audioBuffer: Buffer, mimeType?: string): Promise<string>;
//# sourceMappingURL=stt.d.ts.map