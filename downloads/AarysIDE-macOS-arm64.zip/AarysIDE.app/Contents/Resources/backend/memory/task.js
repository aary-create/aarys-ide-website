// Aary's IDE — Task Memory
import { createMemory, searchMemory } from './store.js';
export function saveTaskMemory(userId, taskId, content, tags = []) {
    return createMemory({ userId, category: 'task', content, tags, taskId, source: 'agent', importance: 0.7 });
}
export function getTaskHistory(userId, taskId) {
    return searchMemory({ query: '', category: 'task', taskId, limit: 50 }, userId);
}
//# sourceMappingURL=task.js.map