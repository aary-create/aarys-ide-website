// Aary's IDE — User Memory
import { createMemory, searchMemory, getMemoriesByCategory } from './store.js';
export function rememberUserPreference(userId, content, tags = []) {
    return createMemory({ userId, category: 'user', content, tags, source: 'agent', importance: 0.8 });
}
export function getUserPreferences(userId) {
    return getMemoriesByCategory(userId, 'user', 20);
}
export function searchUserMemory(userId, query) {
    return searchMemory({ query, category: 'user', limit: 10 }, userId);
}
//# sourceMappingURL=user.js.map