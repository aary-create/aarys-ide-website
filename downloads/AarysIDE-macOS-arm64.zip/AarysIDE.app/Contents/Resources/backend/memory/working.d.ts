import type { AgentMessage } from '@aarys-ide/shared';
export declare function getWorkingMemory(sessionId: string): {
    messages: AgentMessage[];
    metadata: Record<string, unknown>;
};
export declare function setWorkingMemory(sessionId: string, messages: AgentMessage[], metadata?: Record<string, unknown>): void;
export declare function appendMessage(sessionId: string, message: AgentMessage): void;
export declare function clearWorkingMemory(sessionId: string): void;
//# sourceMappingURL=working.d.ts.map