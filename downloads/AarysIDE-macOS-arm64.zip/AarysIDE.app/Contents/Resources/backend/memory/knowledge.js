// Aary's IDE — Knowledge Memory
import { createMemory, searchMemory, getMemoriesByCategory } from './store.js';
export function saveKnowledge(userId, content, tags = []) {
    return createMemory({ userId, category: 'knowledge', content, tags, source: 'agent', importance: 0.6 });
}
export function searchKnowledge(userId, query) {
    return searchMemory({ query, category: 'knowledge', limit: 10 }, userId);
}
export function getRecentKnowledge(userId) {
    return getMemoriesByCategory(userId, 'knowledge', 20);
}
//# sourceMappingURL=knowledge.js.map