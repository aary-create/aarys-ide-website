import type { MemoryEntry, MemoryCategory, MemorySearchQuery, MemorySearchResult } from '@aarys-ide/shared';
export declare function createMemory(entry: Omit<MemoryEntry, 'id' | 'accessCount' | 'createdAt' | 'updatedAt' | 'lastAccessedAt'>): MemoryEntry;
export declare function getMemory(id: string): MemoryEntry | null;
export declare function updateMemory(id: string, updates: Partial<Pick<MemoryEntry, 'content' | 'tags' | 'importance'>>): void;
export declare function deleteMemory(id: string): void;
export declare function searchMemory(query: MemorySearchQuery, userId: string): MemorySearchResult[];
export declare function getMemoriesByCategory(userId: string, category: MemoryCategory, limit?: number): MemoryEntry[];
export declare function clearProjectMemory(userId: string, projectId: string): void;
//# sourceMappingURL=store.d.ts.map