import { createMemory, searchMemory } from './store.js';
export function saveProjectMemory(userId, project) {
    return createMemory({
        userId, category: 'project', content: JSON.stringify(project),
        tags: [project.name, ...(project.techStack || [])], projectId: project.projectId,
        source: 'agent', importance: 0.9,
    });
}
export function getProjectMemory(userId, projectId) {
    const results = searchMemory({ query: '', category: 'project', projectId, limit: 1 }, userId);
    if (results.length === 0)
        return null;
    try {
        return JSON.parse(results[0].entry.content);
    }
    catch {
        return null;
    }
}
export function searchProjectMemory(userId, query) {
    return searchMemory({ query, category: 'project', limit: 10 }, userId);
}
//# sourceMappingURL=project.js.map