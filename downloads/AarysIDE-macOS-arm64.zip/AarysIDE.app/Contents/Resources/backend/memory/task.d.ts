export declare function saveTaskMemory(userId: string, taskId: string, content: string, tags?: string[]): import("@aarys-ide/shared").MemoryEntry;
export declare function getTaskHistory(userId: string, taskId: string): import("@aarys-ide/shared").MemorySearchResult[];
//# sourceMappingURL=task.d.ts.map