const sessionContexts = new Map();
export function getWorkingMemory(sessionId) {
    return sessionContexts.get(sessionId) || { messages: [], metadata: {} };
}
export function setWorkingMemory(sessionId, messages, metadata) {
    sessionContexts.set(sessionId, { messages, metadata: metadata || {} });
}
export function appendMessage(sessionId, message) {
    const ctx = getWorkingMemory(sessionId);
    ctx.messages.push(message);
    sessionContexts.set(sessionId, ctx);
}
export function clearWorkingMemory(sessionId) { sessionContexts.delete(sessionId); }
//# sourceMappingURL=working.js.map