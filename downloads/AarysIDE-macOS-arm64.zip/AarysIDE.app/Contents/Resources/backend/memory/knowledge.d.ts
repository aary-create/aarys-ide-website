export declare function saveKnowledge(userId: string, content: string, tags?: string[]): import("@aarys-ide/shared").MemoryEntry;
export declare function searchKnowledge(userId: string, query: string): import("@aarys-ide/shared").MemorySearchResult[];
export declare function getRecentKnowledge(userId: string): import("@aarys-ide/shared").MemoryEntry[];
//# sourceMappingURL=knowledge.d.ts.map