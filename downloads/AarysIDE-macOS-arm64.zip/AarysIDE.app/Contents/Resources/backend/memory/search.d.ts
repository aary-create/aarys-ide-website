import type { MemorySearchResult } from '@aarys-ide/shared';
export declare function unifiedSearch(userId: string, query: string, limit?: number): MemorySearchResult[];
export declare function getRelevantContext(userId: string, message: string, projectId?: string): string;
//# sourceMappingURL=search.d.ts.map