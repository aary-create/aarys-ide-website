import type { ProjectMemory } from '@aarys-ide/shared';
export declare function saveProjectMemory(userId: string, project: ProjectMemory): import("@aarys-ide/shared").MemoryEntry;
export declare function getProjectMemory(userId: string, projectId: string): ProjectMemory | null;
export declare function searchProjectMemory(userId: string, query: string): import("@aarys-ide/shared").MemorySearchResult[];
//# sourceMappingURL=project.d.ts.map