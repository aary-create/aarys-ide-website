export declare function rememberUserPreference(userId: string, content: string, tags?: string[]): import("@aarys-ide/shared").MemoryEntry;
export declare function getUserPreferences(userId: string): import("@aarys-ide/shared").MemoryEntry[];
export declare function searchUserMemory(userId: string, query: string): import("@aarys-ide/shared").MemorySearchResult[];
//# sourceMappingURL=user.d.ts.map