import Database from 'better-sqlite3';
/**
 * Get or create the singleton database instance.
 */
export declare function getDb(): Database.Database;
export declare const db: Database.Database;
/**
 * Run a query that returns rows.
 */
export declare function query<T = Record<string, unknown>>(sql: string, params?: unknown[]): T[];
/**
 * Run a query that returns a single row.
 */
export declare function queryOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): T | undefined;
/**
 * Run an INSERT/UPDATE/DELETE statement.
 */
export declare function execute(sql: string, params?: unknown[]): Database.RunResult;
/**
 * Run multiple statements in a transaction.
 */
export declare function transaction<T>(fn: () => T): T;
/**
 * Close the database connection.
 */
export declare function closeDb(): void;
//# sourceMappingURL=database.d.ts.map