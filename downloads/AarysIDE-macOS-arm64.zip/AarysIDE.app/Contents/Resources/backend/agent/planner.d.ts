export declare function createPlan(request: string): {
    steps: {
        id: string;
        description: string;
        status: "pending";
    }[];
};
//# sourceMappingURL=planner.d.ts.map