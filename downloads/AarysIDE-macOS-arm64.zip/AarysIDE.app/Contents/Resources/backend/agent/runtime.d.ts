import type { AgentSession, AgentMessage, AgentState } from '@aarys-ide/shared';
import '../tools/filesystem.js';
import '../tools/terminal.js';
import '../tools/git.js';
import '../tools/browser.js';
import '../tools/computer-use.js';
import '../tools/file-gen.js';
export declare function createSession(userId: string, deviceId?: string, workspaceId?: string): AgentSession;
export declare function getSession(sessionId: string): AgentSession | null;
export declare function listSessions(userId: string): Array<{
    id: string;
    title: string;
    updatedAt: string;
}>;
/**
 * Process a user message through the agent pipeline:
 * 1. Add to conversation
 * 2. Retrieve relevant memory
 * 3. Build context
 * 4. Send to AI with tools
 * 5. Execute tool calls in a loop
 * 6. Return final response
 */
export declare function processMessage(sessionId: string, content: string, onStateChange?: (state: AgentState) => void, onStreamChunk?: (chunk: string) => void): Promise<AgentMessage>;
/**
 * Stream a response from the agent.
 */
export declare function streamMessage(sessionId: string, content: string, onStateChange?: (state: AgentState) => void): AsyncGenerator<string>;
//# sourceMappingURL=runtime.d.ts.map