import { generateId } from '@aarys-ide/shared';
import { db } from '../database.js';
export function createTask(userId, sessionId, request, workspaceId, deviceId) {
    const id = generateId();
    const now = new Date().toISOString();
    const task = {
        id, userId, sessionId, title: request.slice(0, 100), originalRequest: request,
        status: 'requested', priority: 'normal', completedSteps: [], pendingSteps: [],
        toolHistory: [], errors: [], results: [], artifacts: [], approvals: [],
        childTaskIds: [], progress: 0, deviceId, workspaceId,
        createdAt: now, updatedAt: now,
    };
    db.prepare(`INSERT INTO tasks (id, user_id, session_id, title, original_request, status, priority, tool_history, errors, results, artifacts, device_id, workspace_id, progress, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(id, userId, sessionId, task.title, request, 'requested', 'normal', '[]', '[]', '[]', '[]', deviceId || null, workspaceId || null, 0, now, now);
    return task;
}
export function updateTaskStatus(taskId, status, progress) {
    const updates = ['status = ?', 'updated_at = ?'];
    const vals = [status, new Date().toISOString()];
    if (progress !== undefined) {
        updates.push('progress = ?');
        vals.push(progress);
    }
    if (status === 'completed' || status === 'failed') {
        updates.push('completed_at = ?');
        vals.push(new Date().toISOString());
    }
    vals.push(taskId);
    db.prepare(`UPDATE tasks SET ${updates.join(', ')} WHERE id = ?`).run(...vals);
}
export function getTask(taskId) {
    const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!row)
        return null;
    return rowToTask(row);
}
export function listTasks(userId, status, limit = 50) {
    let sql = 'SELECT * FROM tasks WHERE user_id = ?';
    const params = [userId];
    if (status?.length) {
        sql += ` AND status IN (${status.map(() => '?').join(',')})`;
        params.push(...status);
    }
    sql += ' ORDER BY updated_at DESC LIMIT ?';
    params.push(limit);
    return db.prepare(sql).all(...params).map(rowToTask);
}
function rowToTask(row) {
    return {
        id: row.id, userId: row.user_id, sessionId: row.session_id,
        title: row.title, originalRequest: row.original_request,
        status: row.status, priority: row.priority, completedSteps: [], pendingSteps: [],
        toolHistory: JSON.parse(row.tool_history || '[]'),
        errors: JSON.parse(row.errors || '[]'),
        results: JSON.parse(row.results || '[]'),
        artifacts: JSON.parse(row.artifacts || '[]'),
        approvals: [], childTaskIds: [],
        progress: row.progress, deviceId: row.device_id, workspaceId: row.workspace_id,
        projectId: row.project_id, createdAt: row.created_at, updatedAt: row.updated_at,
        startedAt: row.started_at, completedAt: row.completed_at,
    };
}
//# sourceMappingURL=orchestrator.js.map