import type { TaskResult } from '@aarys-ide/shared';
export interface VerificationResult {
    verified: boolean;
    status: 'verified' | 'failed' | 'inconclusive';
    details: string;
    evidence?: Record<string, unknown>;
}
export declare function verifyFileExists(filePath: string): Promise<VerificationResult>;
export declare function verifyCommandExecution(cmd: string, cwd?: string): Promise<VerificationResult>;
export declare function verifyGitCommit(repoPath: string): Promise<VerificationResult>;
export declare function verifyTaskResults(results: TaskResult[]): Promise<VerificationResult[]>;
//# sourceMappingURL=verifier.d.ts.map