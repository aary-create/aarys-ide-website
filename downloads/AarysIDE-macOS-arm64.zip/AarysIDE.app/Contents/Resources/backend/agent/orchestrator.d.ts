import type { Task, TaskStatus } from '@aarys-ide/shared';
export declare function createTask(userId: string, sessionId: string, request: string, workspaceId?: string, deviceId?: string): Task;
export declare function updateTaskStatus(taskId: string, status: TaskStatus, progress?: number): void;
export declare function getTask(taskId: string): Task | null;
export declare function listTasks(userId: string, status?: TaskStatus[], limit?: number): Task[];
//# sourceMappingURL=orchestrator.d.ts.map