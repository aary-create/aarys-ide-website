import type { ToolExecutionRequest, ToolExecutionResult } from '@aarys-ide/shared';
export declare class AgentExecutor {
    runTool(request: ToolExecutionRequest): Promise<ToolExecutionResult>;
    runBatch(requests: ToolExecutionRequest[]): Promise<ToolExecutionResult[]>;
}
export declare const defaultExecutor: AgentExecutor;
//# sourceMappingURL=executor.d.ts.map