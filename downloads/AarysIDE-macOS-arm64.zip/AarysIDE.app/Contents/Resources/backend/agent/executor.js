// ============================================================
// Aary's IDE — Agent Executor
// Tool execution engine with timeout and error tracking
// ============================================================
import { executeTool } from '../tools/registry.js';
export class AgentExecutor {
    async runTool(request) {
        try {
            const result = await executeTool(request);
            return result;
        }
        catch (err) {
            return {
                toolName: request.toolName,
                success: false,
                error: err.message || 'Execution failed',
                duration: 0,
            };
        }
    }
    async runBatch(requests) {
        const results = [];
        for (const req of requests) {
            results.push(await this.runTool(req));
        }
        return results;
    }
}
export const defaultExecutor = new AgentExecutor();
//# sourceMappingURL=executor.js.map