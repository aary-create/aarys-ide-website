import type { AgentMessage, AIMessage } from '@aarys-ide/shared';
export interface ContextOptions {
    userId: string;
    sessionId: string;
    projectId?: string;
    maxTokens?: number;
}
export declare function buildAgentContext(messages: AgentMessage[], options: ContextOptions, systemPromptBase: string): AIMessage[];
//# sourceMappingURL=context.d.ts.map