// Aary's IDE — Task Planner (simple for now, AI generates plans)
export function createPlan(request) {
    return { steps: [{ id: '1', description: request, status: 'pending' }] };
}
//# sourceMappingURL=planner.js.map