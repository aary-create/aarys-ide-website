export declare class BrowserController {
    static open(url: string): Promise<boolean>;
    static fetchContent(url: string): Promise<{
        title: string;
        text: string;
    }>;
}
//# sourceMappingURL=automation.d.ts.map