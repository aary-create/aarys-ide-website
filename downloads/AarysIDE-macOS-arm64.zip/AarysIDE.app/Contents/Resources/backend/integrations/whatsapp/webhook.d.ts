import { WhatsAppClient } from './client.js';
export interface InboundWhatsAppMessage {
    from: string;
    id: string;
    timestamp: string;
    type: 'text' | 'audio' | 'voice' | 'image' | 'document';
    text?: {
        body: string;
    };
    audio?: {
        id: string;
        mime_type: string;
    };
}
export declare function handleWhatsAppWebhook(body: any, systemUserId: string, client?: WhatsAppClient): Promise<void>;
//# sourceMappingURL=webhook.d.ts.map