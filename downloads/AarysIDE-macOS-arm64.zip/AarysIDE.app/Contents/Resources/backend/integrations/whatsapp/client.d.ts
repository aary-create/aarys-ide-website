export interface WhatsAppMessagePayload {
    to: string;
    type: 'text' | 'audio' | 'document' | 'template';
    text?: string;
    mediaUrl?: string;
    caption?: string;
}
export declare class WhatsAppClient {
    private phoneNumberId;
    private accessToken;
    private baseUrl;
    constructor(phoneNumberId: string, accessToken: string);
    sendTextMessage(to: string, message: string): Promise<any>;
    sendAudioMessage(to: string, audioUrl: string): Promise<any>;
}
//# sourceMappingURL=client.d.ts.map