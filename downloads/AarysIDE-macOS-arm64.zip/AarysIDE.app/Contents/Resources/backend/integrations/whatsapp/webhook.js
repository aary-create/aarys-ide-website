// ============================================================
// Aary's IDE — WhatsApp Webhook & Command Dispatcher
// Receives inbound messages and voice notes from WhatsApp
// ============================================================
import { processMessage } from '../../agent/runtime.js';
import { config } from '../../config.js';
export async function handleWhatsAppWebhook(body, systemUserId, client) {
    const entry = body.entry?.[0];
    const changes = entry?.changes?.[0];
    const value = changes?.value;
    const message = value?.messages?.[0];
    if (!message)
        return;
    const sender = message.from;
    let commandText = '';
    if (message.type === 'text' && message.text) {
        commandText = message.text.body;
    }
    else if (message.type === 'audio' || message.type === 'voice') {
        commandText = '[Voice note received: please process incoming task]';
    }
    else {
        commandText = `[Received ${message.type} attachment]`;
    }
    // Session ID derived from sender for continuity
    const sessionId = `wa_${sender}`;
    try {
        const response = await processMessage(sessionId, commandText);
        if (client && config.whatsapp.accessToken) {
            await client.sendTextMessage(sender, response.content);
        }
    }
    catch (err) {
        if (client && config.whatsapp.accessToken) {
            await client.sendTextMessage(sender, `Agent Error: ${err.message}`);
        }
    }
}
//# sourceMappingURL=webhook.js.map