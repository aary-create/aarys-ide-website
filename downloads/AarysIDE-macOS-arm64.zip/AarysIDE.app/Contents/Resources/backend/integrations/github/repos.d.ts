import { GitHubClient, type GitHubRepo } from './client.js';
export declare function scanForSensitiveData(dirPath: string): Promise<string[]>;
export declare function createAndPushRepo(client: GitHubClient, projectPath: string, repoName: string, isPrivate: boolean): Promise<{
    repo: GitHubRepo;
    pushed: boolean;
}>;
//# sourceMappingURL=repos.d.ts.map