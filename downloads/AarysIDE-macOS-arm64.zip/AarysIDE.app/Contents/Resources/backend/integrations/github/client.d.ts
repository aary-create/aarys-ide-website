export interface GitHubRepo {
    id: number;
    name: string;
    fullName: string;
    private: boolean;
    htmlUrl: string;
    description: string | null;
    defaultBranch: string;
}
export declare class GitHubClient {
    private token;
    private baseUrl;
    constructor(token: string);
    private request;
    getUser(): Promise<{
        login: string;
        id: number;
        avatar_url: string;
        email?: string;
    }>;
    listRepositories(): Promise<GitHubRepo[]>;
    createRepository(options: {
        name: string;
        description?: string;
        private?: boolean;
        autoInit?: boolean;
    }): Promise<GitHubRepo>;
    listBranches(owner: string, repo: string): Promise<string[]>;
    listIssues(owner: string, repo: string): Promise<any[]>;
    listPullRequests(owner: string, repo: string): Promise<any[]>;
}
//# sourceMappingURL=client.d.ts.map