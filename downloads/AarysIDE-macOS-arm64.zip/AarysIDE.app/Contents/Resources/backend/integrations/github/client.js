// ============================================================
// Aary's IDE — GitHub API Client
// ============================================================
export class GitHubClient {
    token;
    baseUrl = 'https://api.github.com';
    constructor(token) {
        this.token = token;
    }
    async request(path, options = {}) {
        const res = await fetch(`${this.baseUrl}${path}`, {
            ...options,
            headers: {
                Accept: 'application/vnd.github.v3+json',
                Authorization: `Bearer ${this.token}`,
                'User-Agent': 'Aarys-IDE',
                'Content-Type': 'application/json',
                ...options.headers,
            },
        });
        if (!res.ok) {
            const errText = await res.text().catch(() => res.statusText);
            throw new Error(`GitHub API error (${res.status}): ${errText}`);
        }
        return res.json();
    }
    async getUser() {
        return this.request('/user');
    }
    async listRepositories() {
        const raw = await this.request('/user/repos?sort=updated&per_page=100');
        return raw.map((r) => ({
            id: r.id,
            name: r.name,
            fullName: r.full_name,
            private: r.private,
            htmlUrl: r.html_url,
            description: r.description,
            defaultBranch: r.default_branch,
        }));
    }
    async createRepository(options) {
        const r = await this.request('/user/repos', {
            method: 'POST',
            body: JSON.stringify({
                name: options.name,
                description: options.description || '',
                private: options.private ?? false,
                auto_init: options.autoInit ?? false,
            }),
        });
        return {
            id: r.id,
            name: r.name,
            fullName: r.full_name,
            private: r.private,
            htmlUrl: r.html_url,
            description: r.description,
            defaultBranch: r.default_branch,
        };
    }
    async listBranches(owner, repo) {
        const branches = await this.request(`/repos/${owner}/${repo}/branches`);
        return branches.map((b) => b.name);
    }
    async listIssues(owner, repo) {
        return this.request(`/repos/${owner}/${repo}/issues?state=all`);
    }
    async listPullRequests(owner, repo) {
        return this.request(`/repos/${owner}/${repo}/pulls?state=all`);
    }
}
//# sourceMappingURL=client.js.map