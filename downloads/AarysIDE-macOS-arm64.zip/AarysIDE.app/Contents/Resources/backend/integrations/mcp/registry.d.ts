import type { MCPServerConfig } from '@aarys-ide/shared';
export declare function listMCPServers(userId: string): MCPServerConfig[];
export declare function connectMCPServer(config: MCPServerConfig): Promise<boolean>;
export declare function disconnectMCPServer(id: string): void;
//# sourceMappingURL=registry.d.ts.map