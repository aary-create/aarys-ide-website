import type { MCPServerConfig, MCPTool } from '@aarys-ide/shared';
export declare class MCPClient {
    private config;
    private process?;
    private requestId;
    private pendingRequests;
    constructor(config: MCPServerConfig);
    connect(): Promise<boolean>;
    sendRequest<T = any>(method: string, params?: Record<string, unknown>): Promise<T>;
    listTools(): Promise<MCPTool[]>;
    callTool(name: string, argumentsObj: Record<string, unknown>): Promise<any>;
    disconnect(): void;
}
//# sourceMappingURL=client.d.ts.map