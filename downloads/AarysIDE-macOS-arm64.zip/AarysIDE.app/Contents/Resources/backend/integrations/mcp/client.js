// ============================================================
// Aary's IDE — Model Context Protocol (MCP) Client
// Connects to local stdio and remote HTTP/SSE MCP servers
// ============================================================
import { spawn } from 'child_process';
export class MCPClient {
    config;
    process;
    requestId = 0;
    pendingRequests = new Map();
    constructor(config) {
        this.config = config;
    }
    async connect() {
        if (this.config.transport === 'stdio' && this.config.command) {
            return new Promise((resolve) => {
                this.process = spawn(this.config.command, this.config.args || [], {
                    env: { ...process.env, ...this.config.env },
                });
                let buffer = '';
                this.process.stdout?.on('data', (data) => {
                    buffer += data.toString();
                    const lines = buffer.split('\n');
                    buffer = lines.pop() || '';
                    for (const line of lines) {
                        if (!line.trim())
                            continue;
                        try {
                            const res = JSON.parse(line);
                            if (res.id !== undefined && this.pendingRequests.has(res.id)) {
                                const handler = this.pendingRequests.get(res.id);
                                this.pendingRequests.delete(res.id);
                                if (res.error)
                                    handler.reject(new Error(res.error.message || 'MCP Error'));
                                else
                                    handler.resolve(res.result);
                            }
                        }
                        catch {
                            // Ignore non-json logging
                        }
                    }
                });
                this.process.on('error', () => resolve(false));
                resolve(true);
            });
        }
        return false;
    }
    async sendRequest(method, params = {}) {
        if (!this.process || !this.process.stdin) {
            throw new Error(`MCP Server ${this.config.name} is not connected`);
        }
        const id = ++this.requestId;
        const msg = JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n';
        return new Promise((resolve, reject) => {
            this.pendingRequests.set(id, { resolve, reject });
            this.process.stdin.write(msg);
        });
    }
    async listTools() {
        try {
            const res = await this.sendRequest('tools/list');
            return res.tools || [];
        }
        catch {
            return [];
        }
    }
    async callTool(name, argumentsObj) {
        return this.sendRequest('tools/call', { name, arguments: argumentsObj });
    }
    disconnect() {
        if (this.process) {
            this.process.kill();
            this.process = undefined;
        }
    }
}
//# sourceMappingURL=client.js.map