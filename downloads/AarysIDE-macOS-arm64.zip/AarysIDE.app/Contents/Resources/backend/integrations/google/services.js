// ============================================================
// Aary's IDE — Google Services (Gmail, Drive, Calendar, Docs)
// ============================================================
import { GoogleApiClient } from './client.js';
export class GmailIntegration extends GoogleApiClient {
    async listMessages(query = '', maxResults = 10) {
        const q = encodeURIComponent(query);
        const url = `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}&q=${q}`;
        return this.get(url);
    }
    async getMessage(id) {
        const url = `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=full`;
        return this.get(url);
    }
    async sendDraft(to, subject, bodyText) {
        const message = [
            `To: ${to}`,
            `Subject: ${subject}`,
            'Content-Type: text/plain; charset="UTF-8"',
            '',
            bodyText,
        ].join('\r\n');
        const encoded = Buffer.from(message).toString('base64url');
        return this.post('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
            raw: encoded,
        });
    }
}
export class GoogleDriveIntegration extends GoogleApiClient {
    async listFiles(pageSize = 20) {
        const url = `https://www.googleapis.com/drive/v3/files?pageSize=${pageSize}&fields=files(id,name,mimeType,webViewLink,size)`;
        return this.get(url);
    }
    async getFileMetadata(fileId) {
        return this.get(`https://www.googleapis.com/drive/v3/files/${fileId}?fields=*`);
    }
}
export class GoogleCalendarIntegration extends GoogleApiClient {
    async listEvents(timeMin, maxResults = 20) {
        const min = encodeURIComponent(timeMin || new Date().toISOString());
        const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${min}&maxResults=${maxResults}&singleEvents=true&orderBy=startTime`;
        return this.get(url);
    }
    async createEvent(event) {
        return this.post('https://www.googleapis.com/calendar/v3/calendars/primary/events', event);
    }
}
export class GoogleDocsIntegration extends GoogleApiClient {
    async getDocument(documentId) {
        return this.get(`https://docs.googleapis.com/v1/documents/${documentId}`);
    }
    async createDocument(title) {
        return this.post('https://docs.googleapis.com/v1/documents', { title });
    }
}
//# sourceMappingURL=services.js.map