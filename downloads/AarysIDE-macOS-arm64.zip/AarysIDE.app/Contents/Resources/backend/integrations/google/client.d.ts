export declare class GoogleApiClient {
    protected accessToken: string;
    constructor(accessToken: string);
    protected get<T>(url: string): Promise<T>;
    protected post<T>(url: string, body: unknown): Promise<T>;
}
//# sourceMappingURL=client.d.ts.map