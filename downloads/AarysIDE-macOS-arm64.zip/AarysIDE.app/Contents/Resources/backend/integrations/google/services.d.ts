import { GoogleApiClient } from './client.js';
export declare class GmailIntegration extends GoogleApiClient {
    listMessages(query?: string, maxResults?: number): Promise<{
        messages?: Array<{
            id: string;
            threadId: string;
        }>;
    }>;
    getMessage(id: string): Promise<any>;
    sendDraft(to: string, subject: string, bodyText: string): Promise<unknown>;
}
export declare class GoogleDriveIntegration extends GoogleApiClient {
    listFiles(pageSize?: number): Promise<{
        files: Array<{
            id: string;
            name: string;
            mimeType: string;
            webViewLink: string;
            size?: string;
        }>;
    }>;
    getFileMetadata(fileId: string): Promise<any>;
}
export declare class GoogleCalendarIntegration extends GoogleApiClient {
    listEvents(timeMin?: string, maxResults?: number): Promise<{
        items: Array<any>;
    }>;
    createEvent(event: {
        summary: string;
        description?: string;
        start: {
            dateTime: string;
        };
        end: {
            dateTime: string;
        };
    }): Promise<unknown>;
}
export declare class GoogleDocsIntegration extends GoogleApiClient {
    getDocument(documentId: string): Promise<any>;
    createDocument(title: string): Promise<any>;
}
//# sourceMappingURL=services.d.ts.map