// ============================================================
// Aary's IDE — Google API Base Client
// ============================================================
export class GoogleApiClient {
    accessToken;
    constructor(accessToken) {
        this.accessToken = accessToken;
    }
    async get(url) {
        const res = await fetch(url, {
            headers: {
                Authorization: `Bearer ${this.accessToken}`,
                Accept: 'application/json',
            },
        });
        if (!res.ok) {
            const err = await res.text().catch(() => res.statusText);
            throw new Error(`Google API error (${res.status}): ${err}`);
        }
        return res.json();
    }
    async post(url, body) {
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${this.accessToken}`,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = await res.text().catch(() => res.statusText);
            throw new Error(`Google API error (${res.status}): ${err}`);
        }
        return res.json();
    }
}
//# sourceMappingURL=client.js.map