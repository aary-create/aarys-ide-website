export declare class HermesIntegration {
    static checkInstalled(): Promise<{
        installed: boolean;
        version?: string;
    }>;
    static delegate(task: string, model?: string): Promise<{
        success: boolean;
        result: string;
    }>;
}
//# sourceMappingURL=client.d.ts.map