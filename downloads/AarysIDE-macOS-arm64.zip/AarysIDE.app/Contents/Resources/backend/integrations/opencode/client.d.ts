export declare class OpenCodeIntegration {
    static checkInstalled(): Promise<{
        installed: boolean;
        version?: string;
    }>;
    static runTask(prompt: string, cwd: string): Promise<{
        success: boolean;
        output: string;
    }>;
}
//# sourceMappingURL=client.d.ts.map