export declare const workspaceRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=workspace.d.ts.map