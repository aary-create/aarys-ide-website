export declare const memoryRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=memory.d.ts.map