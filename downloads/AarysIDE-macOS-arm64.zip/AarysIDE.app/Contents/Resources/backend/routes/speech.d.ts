export declare const speechRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=speech.d.ts.map