export declare const devicesRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=devices.d.ts.map