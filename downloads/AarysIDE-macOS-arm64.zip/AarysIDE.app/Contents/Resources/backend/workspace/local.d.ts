import type { WorkspaceFile, FileOperation } from '@aarys-ide/shared';
export declare class LocalWorkspace {
    private rootPath;
    constructor(rootPath: string);
    private resolveSafe;
    getFileTree(maxDepth?: number): Promise<WorkspaceFile[]>;
    applyOperation(op: FileOperation): Promise<any>;
}
//# sourceMappingURL=local.d.ts.map