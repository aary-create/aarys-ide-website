import type { FileOperation, WorkspaceFile } from '@aarys-ide/shared';
export declare class RemoteWorkspace {
    private host;
    private user;
    private port;
    constructor(host: string, user: string, port?: number);
    getFileTree(): Promise<WorkspaceFile[]>;
    applyOperation(op: FileOperation): Promise<any>;
}
//# sourceMappingURL=remote.d.ts.map