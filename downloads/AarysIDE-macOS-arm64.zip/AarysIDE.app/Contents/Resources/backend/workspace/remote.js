// ============================================================
// Aary's IDE — Remote Workspace (SSH / Cloud)
// ============================================================
export class RemoteWorkspace {
    host;
    user;
    port;
    constructor(host, user, port = 22) {
        this.host = host;
        this.user = user;
        this.port = port;
    }
    async getFileTree() {
        // Remote SSH file listing stub with configuration state
        return [];
    }
    async applyOperation(op) {
        throw new Error(`Remote SSH operations on ${this.user}@${this.host}:${this.port} require configured SSH keys`);
    }
}
//# sourceMappingURL=remote.js.map