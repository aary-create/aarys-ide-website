import type { Workspace } from '@aarys-ide/shared';
import { LocalWorkspace } from './local.js';
export declare function listWorkspaces(userId: string): Workspace[];
export declare function createWorkspace(userId: string, name: string, dirPath: string, type?: 'local' | 'remote'): Promise<Workspace>;
export declare function getLocalWorkspace(workspaceId: string): LocalWorkspace | null;
//# sourceMappingURL=manager.d.ts.map