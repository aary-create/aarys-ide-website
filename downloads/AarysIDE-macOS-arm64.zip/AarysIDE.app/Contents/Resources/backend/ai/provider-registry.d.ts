import type { AIProviderConfig, AIModel, AIProviderType } from '@aarys-ide/shared';
import type { AIAdapter } from './adapters/base.js';
export declare function getAdapter(type: AIProviderType): AIAdapter;
export declare function listProviders(userId: string): AIProviderConfig[];
export declare function getProviderConfig(providerId: string): {
    config: AIProviderConfig;
    apiKey: string;
} | null;
export declare function addProvider(userId: string, type: AIProviderType, name: string, apiKey: string, baseUrl?: string): Promise<AIProviderConfig>;
export declare function testProvider(providerId: string): Promise<{
    connected: boolean;
    models: AIModel[];
    error?: string;
}>;
export declare function removeProvider(providerId: string): void;
export declare function updateProvider(providerId: string, updates: Partial<{
    name: string;
    enabled: boolean;
    defaultModelId: string;
    apiKey: string;
    baseUrl: string;
}>): void;
//# sourceMappingURL=provider-registry.d.ts.map