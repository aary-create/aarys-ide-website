import type { ModelCapabilities } from '@aarys-ide/shared';
export declare function detectCapabilities(modelId: string, providerType: string): ModelCapabilities;
//# sourceMappingURL=capability-detector.d.ts.map