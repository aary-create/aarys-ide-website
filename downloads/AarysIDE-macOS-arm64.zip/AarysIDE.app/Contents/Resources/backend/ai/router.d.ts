import type { AICompletionRequest, AICompletionResponse, AIStreamChunk, RoutingPreferences } from '@aarys-ide/shared';
export type TaskType = 'coding' | 'research' | 'planning' | 'vision' | 'voice' | 'summarization' | 'tool_execution' | 'general';
export declare function detectTaskType(message: string): TaskType;
export declare function selectModel(userId: string, taskType: TaskType, preferences?: RoutingPreferences): {
    providerId: string;
    modelId: string;
    apiKey: string;
    baseUrl?: string;
} | null;
export declare function routeCompletion(userId: string, request: AICompletionRequest, providerId?: string): Promise<AICompletionResponse>;
export declare function routeStream(userId: string, request: AICompletionRequest, providerId?: string): AsyncGenerator<AIStreamChunk>;
//# sourceMappingURL=router.d.ts.map