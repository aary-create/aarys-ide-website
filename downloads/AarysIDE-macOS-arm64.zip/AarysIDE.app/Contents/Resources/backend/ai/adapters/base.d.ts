import type { AICompletionRequest, AICompletionResponse, AIStreamChunk, AIModel, ModelCapabilities } from '@aarys-ide/shared';
export interface AIAdapter {
    readonly type: string;
    readonly name: string;
    /** Test if the connection works */
    testConnection(apiKey: string, baseUrl?: string): Promise<boolean>;
    /** List available models */
    listModels(apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    /** Send a completion request */
    complete(request: AICompletionRequest, apiKey: string, baseUrl?: string): Promise<AICompletionResponse>;
    /** Send a streaming completion request */
    stream(request: AICompletionRequest, apiKey: string, baseUrl?: string): AsyncGenerator<AIStreamChunk>;
    /** Detect capabilities of a specific model */
    detectCapabilities(modelId: string): ModelCapabilities;
}
/** Helper to make HTTP requests to AI APIs */
export declare function fetchAI(url: string, body: unknown, apiKey: string, headers?: Record<string, string>): Promise<Response>;
/** Parse SSE stream lines into chunks */
export declare function parseSSEStream(response: Response): AsyncGenerator<string>;
//# sourceMappingURL=base.d.ts.map