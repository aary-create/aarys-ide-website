// ============================================================
// Aary's IDE — AI Provider Base Adapter
// ============================================================
/** Helper to make HTTP requests to AI APIs */
export async function fetchAI(url, body, apiKey, headers) {
    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
            ...headers,
        },
        body: JSON.stringify(body),
    });
    if (!res.ok) {
        const error = await res.text().catch(() => res.statusText);
        throw new Error(`AI API error (${res.status}): ${error}`);
    }
    return res;
}
/** Parse SSE stream lines into chunks */
export async function* parseSSEStream(response) {
    const reader = response.body?.getReader();
    if (!reader)
        throw new Error('No response body');
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
        const { done, value } = await reader.read();
        if (done)
            break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
                const data = trimmed.slice(6);
                if (data === '[DONE]')
                    return;
                yield data;
            }
        }
    }
}
//# sourceMappingURL=base.js.map