// ============================================================
// Aary's IDE — OmniRoute Adapter
// OpenAI-compatible API
// ============================================================
import { OpenAIAdapter } from './openai.js';
export class OmniRouteAdapter extends OpenAIAdapter {
    type = 'omniroute';
    name = 'OmniRoute';
    async listModels(apiKey, baseUrl) {
        try {
            const models = await super.listModels(apiKey, baseUrl || 'https://api.omniroute.ai/v1');
            return models.map(m => ({ ...m, providerId: 'omniroute' }));
        }
        catch {
            // Return common models if listing fails
            return ['omniroute-auto', 'omniroute-fast', 'omniroute-best'].map(id => ({
                id, name: id, providerId: 'omniroute',
                capabilities: this.detectCapabilities(id),
            }));
        }
    }
    async testConnection(apiKey, baseUrl) {
        return super.testConnection(apiKey, baseUrl || 'https://api.omniroute.ai/v1');
    }
    detectCapabilities(_modelId) {
        return {
            toolCalling: true, vision: true, audio: false, speech: false,
            structuredOutput: true, streaming: true, longContext: true,
            coding: true, reasoning: true,
        };
    }
}
//# sourceMappingURL=omniroute.js.map