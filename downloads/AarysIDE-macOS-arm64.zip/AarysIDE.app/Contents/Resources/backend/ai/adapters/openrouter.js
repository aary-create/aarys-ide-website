// ============================================================
// Aary's IDE — OpenRouter Adapter
// ============================================================
import { OpenAIAdapter } from './openai.js';
export class OpenRouterAdapter extends OpenAIAdapter {
    type = 'openrouter';
    name = 'OpenRouter';
    async listModels(apiKey, baseUrl) {
        const url = `${baseUrl || 'https://openrouter.ai/api/v1'}/models`;
        const res = await fetch(url, { headers: { Authorization: `Bearer ${apiKey}` } });
        if (!res.ok)
            throw new Error(`OpenRouter models error: ${res.statusText}`);
        const data = await res.json();
        return (data.data || []).slice(0, 100).map((m) => ({
            id: m.id, name: m.name || m.id, providerId: 'openrouter',
            capabilities: this.detectCapabilities(m.id),
            contextWindow: m.context_length,
        }));
    }
    async testConnection(apiKey, baseUrl) {
        return super.testConnection(apiKey, baseUrl || 'https://openrouter.ai/api/v1');
    }
    detectCapabilities(modelId) {
        return {
            toolCalling: true, vision: modelId.includes('vision') || modelId.includes('gpt-4'),
            audio: false, speech: false, structuredOutput: true, streaming: true,
            longContext: true, coding: true, reasoning: modelId.includes('o1') || modelId.includes('claude'),
        };
    }
}
//# sourceMappingURL=openrouter.js.map