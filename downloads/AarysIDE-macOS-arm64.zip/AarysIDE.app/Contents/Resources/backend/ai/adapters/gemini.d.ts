import type { AICompletionRequest, AICompletionResponse, AIStreamChunk, AIModel, ModelCapabilities } from '@aarys-ide/shared';
import { type AIAdapter } from './base.js';
export declare class GeminiAdapter implements AIAdapter {
    readonly type = "gemini";
    readonly name = "Google Gemini";
    testConnection(apiKey: string, baseUrl?: string): Promise<boolean>;
    listModels(apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    complete(req: AICompletionRequest, apiKey: string, baseUrl?: string): Promise<AICompletionResponse>;
    stream(req: AICompletionRequest, apiKey: string, baseUrl?: string): AsyncGenerator<AIStreamChunk>;
    detectCapabilities(modelId: string): ModelCapabilities;
}
//# sourceMappingURL=gemini.d.ts.map