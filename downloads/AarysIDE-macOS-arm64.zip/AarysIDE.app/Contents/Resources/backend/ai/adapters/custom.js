// ============================================================
// Aary's IDE — Custom OpenAI-Compatible Adapter
// ============================================================
import { OpenAIAdapter } from './openai.js';
export class CustomAdapter extends OpenAIAdapter {
    type = 'custom';
    name = 'Custom API';
    async listModels(apiKey, baseUrl) {
        if (!baseUrl)
            return [];
        try {
            const models = await super.listModels(apiKey, baseUrl);
            return models.map(m => ({ ...m, providerId: 'custom' }));
        }
        catch {
            return [{ id: 'default', name: 'Default Model', providerId: 'custom', capabilities: this.detectCapabilities('default') }];
        }
    }
    detectCapabilities(_modelId) {
        return {
            toolCalling: true, vision: false, audio: false, speech: false,
            structuredOutput: true, streaming: true, longContext: false,
            coding: true, reasoning: false,
        };
    }
}
//# sourceMappingURL=custom.js.map