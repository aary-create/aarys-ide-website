import type { AIModel, ModelCapabilities } from '@aarys-ide/shared';
import { OpenAIAdapter } from './openai.js';
export declare class OmniRouteAdapter extends OpenAIAdapter {
    readonly type = "omniroute";
    readonly name = "OmniRoute";
    listModels(apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    testConnection(apiKey: string, baseUrl?: string): Promise<boolean>;
    detectCapabilities(_modelId: string): ModelCapabilities;
}
//# sourceMappingURL=omniroute.d.ts.map