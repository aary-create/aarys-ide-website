import type { AIModel, ModelCapabilities } from '@aarys-ide/shared';
import { OpenAIAdapter } from './openai.js';
export declare class CustomAdapter extends OpenAIAdapter {
    readonly type = "custom";
    readonly name = "Custom API";
    listModels(apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    detectCapabilities(_modelId: string): ModelCapabilities;
}
//# sourceMappingURL=custom.d.ts.map