// ============================================================
// Aary's IDE — Anthropic Adapter
// Real API calls to api.anthropic.com
// ============================================================
import { parseSSEStream } from './base.js';
export class AnthropicAdapter {
    type = 'anthropic';
    name = 'Anthropic';
    async testConnection(apiKey, baseUrl) {
        const url = `${baseUrl || 'https://api.anthropic.com'}/v1/messages`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 10,
                messages: [{ role: 'user', content: 'hi' }],
            }),
        });
        return res.ok;
    }
    async listModels(apiKey, _baseUrl) {
        // Anthropic doesn't have a list models endpoint; return known models
        const models = [
            'claude-opus-4-20250514',
            'claude-sonnet-4-20250514',
            'claude-3-5-haiku-20241022',
            'claude-3-5-sonnet-20241022',
        ];
        return models.map(id => ({
            id,
            name: id.replace(/-\d{8}$/, '').replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
            providerId: 'anthropic',
            capabilities: this.detectCapabilities(id),
        }));
    }
    async complete(request, apiKey, baseUrl) {
        const url = `${baseUrl || 'https://api.anthropic.com'}/v1/messages`;
        // Convert messages from OpenAI format to Anthropic format
        const systemMsg = request.messages.find(m => m.role === 'system');
        const messages = request.messages
            .filter(m => m.role !== 'system')
            .map(m => ({
            role: m.role === 'tool' ? 'user' : m.role,
            content: m.role === 'tool'
                ? [{ type: 'tool_result', tool_use_id: m.toolCallId || '', content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }]
                : typeof m.content === 'string' ? m.content : JSON.stringify(m.content),
        }));
        const body = {
            model: request.model,
            max_tokens: request.maxTokens || 4096,
            messages,
        };
        if (systemMsg) {
            body.system = typeof systemMsg.content === 'string' ? systemMsg.content : '';
        }
        if (request.tools?.length) {
            body.tools = request.tools.map(t => ({
                name: t.function.name,
                description: t.function.description,
                input_schema: t.function.parameters,
            }));
        }
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = await res.text();
            throw new Error(`Anthropic API error (${res.status}): ${err}`);
        }
        const data = await res.json();
        const textBlocks = data.content.filter((b) => b.type === 'text');
        const toolBlocks = data.content.filter((b) => b.type === 'tool_use');
        return {
            id: data.id,
            model: data.model,
            content: textBlocks.map((b) => b.text).join(''),
            toolCalls: toolBlocks.length > 0 ? toolBlocks.map((b) => ({
                id: b.id,
                type: 'function',
                function: { name: b.name, arguments: JSON.stringify(b.input) },
            })) : undefined,
            usage: {
                promptTokens: data.usage.input_tokens,
                completionTokens: data.usage.output_tokens,
                totalTokens: data.usage.input_tokens + data.usage.output_tokens,
            },
            finishReason: data.stop_reason === 'tool_use' ? 'tool_calls' : 'stop',
        };
    }
    async *stream(request, apiKey, baseUrl) {
        const url = `${baseUrl || 'https://api.anthropic.com'}/v1/messages`;
        const systemMsg = request.messages.find(m => m.role === 'system');
        const messages = request.messages
            .filter(m => m.role !== 'system')
            .map(m => ({ role: m.role, content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }));
        const body = {
            model: request.model,
            max_tokens: request.maxTokens || 4096,
            messages,
            stream: true,
        };
        if (systemMsg)
            body.system = typeof systemMsg.content === 'string' ? systemMsg.content : '';
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify(body),
        });
        if (!res.ok)
            throw new Error(`Anthropic stream error: ${res.status}`);
        for await (const line of parseSSEStream(res)) {
            try {
                const evt = JSON.parse(line);
                if (evt.type === 'content_block_delta' && evt.delta?.type === 'text_delta') {
                    yield {
                        id: '',
                        delta: { content: evt.delta.text },
                    };
                }
            }
            catch { /* skip */ }
        }
    }
    detectCapabilities(modelId) {
        const isOpus = modelId.includes('opus');
        const isSonnet = modelId.includes('sonnet');
        return {
            toolCalling: true,
            vision: true,
            audio: false,
            speech: false,
            structuredOutput: true,
            streaming: true,
            longContext: true,
            coding: true,
            reasoning: isOpus || isSonnet,
            maxContextTokens: 200000,
        };
    }
}
//# sourceMappingURL=anthropic.js.map