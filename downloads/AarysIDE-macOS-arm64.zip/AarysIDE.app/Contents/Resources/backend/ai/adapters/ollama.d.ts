import type { AICompletionRequest, AICompletionResponse, AIStreamChunk, AIModel, ModelCapabilities } from '@aarys-ide/shared';
import type { AIAdapter } from './base.js';
export declare class OllamaAdapter implements AIAdapter {
    readonly type = "ollama";
    readonly name = "Ollama (Local)";
    testConnection(_apiKey: string, baseUrl?: string): Promise<boolean>;
    listModels(_apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    complete(req: AICompletionRequest, _apiKey: string, baseUrl?: string): Promise<AICompletionResponse>;
    stream(req: AICompletionRequest, _apiKey: string, baseUrl?: string): AsyncGenerator<AIStreamChunk>;
    detectCapabilities(modelId: string): ModelCapabilities;
}
//# sourceMappingURL=ollama.d.ts.map