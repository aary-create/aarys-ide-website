import type { AICompletionRequest, AICompletionResponse, AIStreamChunk, AIModel, ModelCapabilities } from '@aarys-ide/shared';
import { type AIAdapter } from './base.js';
export declare class OpenAIAdapter implements AIAdapter {
    readonly type: any;
    readonly name: string;
    testConnection(apiKey: string, baseUrl?: string): Promise<boolean>;
    listModels(apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    complete(request: AICompletionRequest, apiKey: string, baseUrl?: string): Promise<AICompletionResponse>;
    stream(request: AICompletionRequest, apiKey: string, baseUrl?: string): AsyncGenerator<AIStreamChunk>;
    detectCapabilities(modelId: string): ModelCapabilities;
}
//# sourceMappingURL=openai.d.ts.map