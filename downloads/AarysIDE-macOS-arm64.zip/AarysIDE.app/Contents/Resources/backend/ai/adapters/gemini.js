// ============================================================
// Aary's IDE — Google Gemini Adapter
// ============================================================
import { parseSSEStream } from './base.js';
export class GeminiAdapter {
    type = 'gemini';
    name = 'Google Gemini';
    async testConnection(apiKey, baseUrl) {
        const url = `${baseUrl || 'https://generativelanguage.googleapis.com'}/v1beta/models?key=${apiKey}`;
        const res = await fetch(url);
        return res.ok;
    }
    async listModels(apiKey, baseUrl) {
        const url = `${baseUrl || 'https://generativelanguage.googleapis.com'}/v1beta/models?key=${apiKey}`;
        const res = await fetch(url);
        if (!res.ok)
            throw new Error(`Gemini models error: ${res.statusText}`);
        const data = await res.json();
        return (data.models || [])
            .filter((m) => m.name.includes('gemini'))
            .map((m) => ({
            id: m.name.replace('models/', ''),
            name: m.displayName || m.name,
            providerId: 'gemini',
            capabilities: this.detectCapabilities(m.name),
        }));
    }
    async complete(req, apiKey, baseUrl) {
        const base = baseUrl || 'https://generativelanguage.googleapis.com';
        const url = `${base}/v1beta/models/${req.model}:generateContent?key=${apiKey}`;
        const systemInstruction = req.messages.find(m => m.role === 'system');
        const contents = req.messages
            .filter(m => m.role !== 'system')
            .map(m => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }],
        }));
        const body = { contents };
        if (systemInstruction) {
            body.systemInstruction = { parts: [{ text: typeof systemInstruction.content === 'string' ? systemInstruction.content : '' }] };
        }
        if (req.tools?.length) {
            body.tools = [{
                    functionDeclarations: req.tools.map(t => ({
                        name: t.function.name,
                        description: t.function.description,
                        parameters: t.function.parameters,
                    })),
                }];
        }
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
        if (!res.ok)
            throw new Error(`Gemini error (${res.status}): ${await res.text()}`);
        const data = await res.json();
        const candidate = data.candidates?.[0];
        const parts = candidate?.content?.parts || [];
        const textParts = parts.filter((p) => p.text);
        const fnParts = parts.filter((p) => p.functionCall);
        return {
            id: `gemini-${Date.now()}`,
            model: req.model,
            content: textParts.map((p) => p.text).join(''),
            toolCalls: fnParts.length ? fnParts.map((p, i) => ({
                id: `call_${i}`,
                type: 'function',
                function: { name: p.functionCall.name, arguments: JSON.stringify(p.functionCall.args) },
            })) : undefined,
            usage: data.usageMetadata ? {
                promptTokens: data.usageMetadata.promptTokenCount || 0,
                completionTokens: data.usageMetadata.candidatesTokenCount || 0,
                totalTokens: data.usageMetadata.totalTokenCount || 0,
            } : undefined,
            finishReason: fnParts.length ? 'tool_calls' : 'stop',
        };
    }
    async *stream(req, apiKey, baseUrl) {
        const base = baseUrl || 'https://generativelanguage.googleapis.com';
        const url = `${base}/v1beta/models/${req.model}:streamGenerateContent?alt=sse&key=${apiKey}`;
        const contents = req.messages.filter(m => m.role !== 'system').map(m => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }],
        }));
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contents }),
        });
        if (!res.ok)
            throw new Error(`Gemini stream error: ${res.status}`);
        for await (const line of parseSSEStream(res)) {
            try {
                const data = JSON.parse(line);
                const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text)
                    yield { id: `gemini-${Date.now()}`, delta: { content: text } };
            }
            catch { /* skip */ }
        }
    }
    detectCapabilities(modelId) {
        const isPro = modelId.includes('pro');
        return {
            toolCalling: true, vision: true, audio: modelId.includes('2.'),
            speech: false, structuredOutput: true, streaming: true,
            longContext: true, coding: true, reasoning: isPro,
            maxContextTokens: modelId.includes('2.') ? 2000000 : 1000000,
        };
    }
}
//# sourceMappingURL=gemini.js.map