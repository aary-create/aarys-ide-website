import type { AIModel, ModelCapabilities } from '@aarys-ide/shared';
import { OpenAIAdapter } from './openai.js';
export declare class OpenRouterAdapter extends OpenAIAdapter {
    readonly type = "openrouter";
    readonly name = "OpenRouter";
    listModels(apiKey: string, baseUrl?: string): Promise<AIModel[]>;
    testConnection(apiKey: string, baseUrl?: string): Promise<boolean>;
    detectCapabilities(modelId: string): ModelCapabilities;
}
//# sourceMappingURL=openrouter.d.ts.map