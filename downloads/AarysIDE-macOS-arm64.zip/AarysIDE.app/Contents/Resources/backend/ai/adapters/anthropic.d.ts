import type { AICompletionRequest, AICompletionResponse, AIStreamChunk, AIModel, ModelCapabilities } from '@aarys-ide/shared';
import { type AIAdapter } from './base.js';
export declare class AnthropicAdapter implements AIAdapter {
    readonly type = "anthropic";
    readonly name = "Anthropic";
    testConnection(apiKey: string, baseUrl?: string): Promise<boolean>;
    listModels(apiKey: string, _baseUrl?: string): Promise<AIModel[]>;
    complete(request: AICompletionRequest, apiKey: string, baseUrl?: string): Promise<AICompletionResponse>;
    stream(request: AICompletionRequest, apiKey: string, baseUrl?: string): AsyncGenerator<AIStreamChunk>;
    detectCapabilities(modelId: string): ModelCapabilities;
}
//# sourceMappingURL=anthropic.d.ts.map