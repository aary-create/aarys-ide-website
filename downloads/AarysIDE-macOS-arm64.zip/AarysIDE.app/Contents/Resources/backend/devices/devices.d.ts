import type { Device, DeviceSync } from '@aarys-ide/shared';
export declare function listDevices(userId: string): Device[];
export declare function registerDevice(userId: string, device: Partial<Device>): Device;
export declare function syncDeviceData(sync: DeviceSync): {
    status: 'synced' | 'pending';
};
//# sourceMappingURL=devices.d.ts.map