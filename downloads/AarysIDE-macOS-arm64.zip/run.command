#!/bin/bash
cd "$(dirname "$0")"
echo "Launching Aary's IDE..."
./AarysIDE.app/Contents/MacOS/aarys-ide
