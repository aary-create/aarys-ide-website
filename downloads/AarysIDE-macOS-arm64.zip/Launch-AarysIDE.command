#!/bin/bash
DIR=""
"/AarysIDE.app/Contents/MacOS/aarys-ide"
