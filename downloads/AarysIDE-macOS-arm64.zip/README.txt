Aary's IDE v1.0.0 — Universal AI Agent IDE
=========================================
Includes Live Preview Canvas, Real-time AI Agent Activity Feed, Monaco Editor, and Full Local Runtime.

To launch:
Double-click Launch-AarysIDE.command or run open AarysIDE.app
